package com.moviesorter.ui;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.accessibility.AccessibilityManager;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.moviesorter.R;
import com.moviesorter.service.FloatingService;
import com.moviesorter.service.ProjectionHolder;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_MEDIA_PROJECTION = 1001;
    private TextView tvStatus;
    private MediaProjectionManager projectionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        tvStatus = findViewById(R.id.tvStatus);

        findViewById(R.id.btnOverlayPermission).setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });

        findViewById(R.id.btnAccessibility).setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        findViewById(R.id.btnStart).setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                tvStatus.setText("Need overlay permission first");
                return;
            }
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_MEDIA_PROJECTION);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MEDIA_PROJECTION && resultCode == Activity.RESULT_OK) {
            // Get MediaProjection HERE in the activity, store in static holder
            // This avoids Android 14/15 bug where passing via Intent extra kills the token
            MediaProjection projection = projectionManager.getMediaProjection(resultCode, data);
            ProjectionHolder.set(projection);

            // Start service — no need to pass projection data in intent now
            startForegroundService(new Intent(this, FloatingService.class));
            tvStatus.setText("✓ Running — tap ▶ button");
            // Finish after short delay so service has time to read from holder
            tvStatus.postDelayed(this::finish, 1000);
        } else if (requestCode == REQ_MEDIA_PROJECTION) {
            tvStatus.setText("Screen capture denied");
        }
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> services = am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : services) {
            if (info.getId().contains("com.moviesorter")) return true;
        }
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Only show permission status if not in "running" state
        if (ProjectionHolder.get() == null) {
            boolean overlay = Settings.canDrawOverlays(this);
            boolean a11y = isAccessibilityEnabled();
            tvStatus.setText("Overlay: " + (overlay ? "✓" : "✗") +
                    "  |  Accessibility: " + (a11y ? "✓" : "✗"));
        }
    }
}
