package com.moviesorter.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

public class TapAccessibilityService extends AccessibilityService {

    private static final String TAG = "TapA11y";
    private static volatile TapAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());

    public static TapAccessibilityService getInstance() { return instance; }
    public static boolean isRunning() { return instance != null; }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.d(TAG, "✅ onServiceConnected fired, instance set");

        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY
                    | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            info.notificationTimeout = 100;
            setServiceInfo(info);
        }
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy — clearing instance");
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    public void tap(float x, float y, Runnable onDone) {
        Path path = new Path();
        path.moveTo(x, y);
        path.lineTo(x, y);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 150))
                .build();

        dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription g) {
                if (onDone != null) handler.post(onDone);
            }
            @Override
            public void onCancelled(GestureDescription g) {
                if (onDone != null) handler.post(onDone);
            }
        }, handler);
    }

    public void tapPosterThenSlot(float px, float py, float sx, float sy, Runnable onDone) {
        tap(px, py, () -> handler.postDelayed(() -> tap(sx, sy, onDone), 700));
    }
}
