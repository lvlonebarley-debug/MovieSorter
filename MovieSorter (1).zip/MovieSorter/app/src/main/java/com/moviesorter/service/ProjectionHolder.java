package com.moviesorter.service;

import android.media.projection.MediaProjection;

// Static holder so MainActivity can pass MediaProjection directly to FloatingService
// without going through Intent extras (which breaks on Android 14+)
public class ProjectionHolder {
    private static volatile MediaProjection projection;

    public static void set(MediaProjection p) { projection = p; }
    public static MediaProjection get() { return projection; }
    public static void clear() { projection = null; }
}
