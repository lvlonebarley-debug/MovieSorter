package com.moviesorter.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import com.moviesorter.R;
import com.moviesorter.ml.PosterProcessor;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FloatingService extends Service {

    private static final String TAG = "FloatingService";
    private static final String CHANNEL_ID = "MovieSorterChannel";
    private static final int NOTIF_ID = 1;

    private WindowManager wm;
    private View floatingView;
    private TextView tvState;
    private boolean buttonShown = false;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private int screenW, screenH, screenDpi;
    private SortEngine engine;
    private boolean isBusy = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService captureExecutor = Executors.newSingleThreadExecutor();

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        engine = new SortEngine();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        screenDpi = dm.densityDpi;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!buttonShown) {
            if (android.provider.Settings.canDrawOverlays(this)) {
                showFloatingButton();
                buttonShown = true;
            } else {
                Log.e(TAG, "No overlay permission");
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        // Delay projection setup slightly so MainActivity has time to set ProjectionHolder
        mainHandler.postDelayed(this::initProjection, 500);
        return START_NOT_STICKY;
    }

    private void initProjection() {
        if (mediaProjection == null) {
            MediaProjection projection = ProjectionHolder.get();
            if (projection != null) {
                mediaProjection = projection;
                mediaProjection.registerCallback(new MediaProjection.Callback() {
                    @Override
                    public void onStop() {
                        Log.w(TAG, "MediaProjection stopped");
                        mediaProjection = null;
                        virtualDisplay = null;
                        imageReader = null;
                    }
                }, mainHandler);
                setupImageReader();
                setStatus("▶ Ready");
                Log.d(TAG, "Projection initialized OK");
            } else {
                Log.e(TAG, "ProjectionHolder is null after delay");
                setStatus("❌ No capture — restart app");
            }
        }
    }

    private void setupImageReader() {
        imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "MovieSorterCapture",
                screenW, screenH, screenDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, null);
    }

    private void showFloatingButton() {
        try {
            // Build view programmatically — no XML inflation, eliminates layout bugs
            android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
            layout.setOrientation(android.widget.LinearLayout.VERTICAL);
            layout.setBackgroundColor(0xCC1a1a2e);
            layout.setPadding(16, 8, 16, 8);

            TextView btnPlay = new TextView(this);
            btnPlay.setText("▶ START");
            btnPlay.setTextColor(0xFFFFFFFF);
            btnPlay.setTextSize(18);
            btnPlay.setPadding(24, 16, 24, 16);
            btnPlay.setBackground(null);

            TextView btnClose = new TextView(this);
            btnClose.setText("✕");
            btnClose.setTextColor(0xFFFF4444);
            btnClose.setTextSize(14);
            btnClose.setPadding(24, 8, 24, 8);

            tvState = new TextView(this);
            tvState.setText("▶ Ready");
            tvState.setTextColor(0xFFAAAAAA);
            tvState.setTextSize(10);

            layout.addView(btnPlay);
            layout.addView(btnClose);
            layout.addView(tvState);

            floatingView = layout;

            btnPlay.setOnTouchListener((v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_UP) onButtonClick();
                return true;
            });
            btnClose.setOnTouchListener((v, e) -> {
                if (e.getAction() == MotionEvent.ACTION_UP) stopSelf();
                return true;
            });

            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.START;
            params.x = 16;
            params.y = 300;

            layout.setOnTouchListener(new View.OnTouchListener() {
                int initX, initY;
                float initTouchX, initTouchY;
                boolean moved;
                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            initX = params.x; initY = params.y;
                            initTouchX = e.getRawX(); initTouchY = e.getRawY();
                            moved = false;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            int dx = (int)(e.getRawX() - initTouchX);
                            int dy = (int)(e.getRawY() - initTouchY);
                            if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true;
                            params.x = initX + dx;
                            params.y = initY + dy;
                            wm.updateViewLayout(floatingView, params);
                            return true;
                        case MotionEvent.ACTION_UP:
                            // Let child touch listeners handle taps
                            return !moved;
                    }
                    return false;
                }
            });

            wm.addView(floatingView, params);
            Log.d(TAG, "✅ Overlay added successfully");
        } catch (Exception e) {
            Log.e(TAG, "❌ Failed to add overlay: " + e.getMessage(), e);
        }
    }

    private void onButtonClick() {
        if (isBusy) {
            isBusy = false;
            setStatus("▶ Ready");
            return;
        }

        TapAccessibilityService acc = TapAccessibilityService.getInstance();
        if (acc == null) {
            setStatus("❌ A11y null - toggle OFF then ON");
            Toast.makeText(this,
                "Toggle MovieSorter Tap OFF then ON in Accessibility",
                Toast.LENGTH_LONG).show();
            return;
        }

        if (mediaProjection == null) {
            setStatus("❌ Tap here then restart app");
            // Launch MainActivity to re-request screen capture
            Intent i = new Intent(this, com.moviesorter.ui.MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            return;
        }

        isBusy = true;
        setStatus("📸 Capturing...");
        mainHandler.postDelayed(() -> captureExecutor.execute(this::captureAndProcess), 800);
    }

    private void captureAndProcess() {
        Bitmap screenshot = captureScreen();
        if (screenshot == null) {
            mainHandler.post(() -> { setStatus("❌ Capture failed"); isBusy = false; });
            return;
        }

        mainHandler.post(() -> setStatus("🔍 Reading posters..."));

        engine.process(screenshot, screenW, screenH, new SortEngine.Callback() {
            @Override
            public void onLog(String msg) {
                Log.d(TAG, msg);
                mainHandler.post(() -> setStatus(msg));
            }

            @Override
            public void onDone(List<PosterProcessor.PosterRegion> sorted, float[] slotPositions) {
                screenshot.recycle();
                mainHandler.post(() -> executeTaps(sorted, slotPositions));
            }

            @Override
            public void onError(String msg) {
                screenshot.recycle();
                mainHandler.post(() -> { setStatus("❌ " + msg); isBusy = false; });
            }
        });
    }

    private void executeTaps(List<PosterProcessor.PosterRegion> sorted, float[] slots) {
        TapAccessibilityService acc = TapAccessibilityService.getInstance();
        if (acc == null) {
            setStatus("❌ Accessibility lost");
            isBusy = false;
            return;
        }
        setStatus("👆 Tapping...");
        tapNext(acc, sorted, slots, 0);
    }

    private void tapNext(TapAccessibilityService acc,
                         List<PosterProcessor.PosterRegion> sorted,
                         float[] slots, int index) {
        if (index >= sorted.size()) {
            mainHandler.post(() -> { setStatus("✅ Done!"); isBusy = false; });
            return;
        }

        PosterProcessor.PosterRegion poster = sorted.get(index);
        float slotX = slots[index * 2];
        float slotY = slots[index * 2 + 1];

        String title = poster.title != null ? poster.title : "?";
        if (title.length() > 20) title = title.substring(0, 20) + "...";
        final String displayTitle = title;

        mainHandler.post(() -> setStatus("👆 Placing: " + displayTitle));

        // Use handler delays instead of Thread.sleep
        acc.tapPosterThenSlot(poster.centerX, poster.centerY, slotX, slotY, () ->
            mainHandler.postDelayed(() -> tapNext(acc, sorted, slots, index + 1), 800)
        );
    }

    private Bitmap captureScreen() {
        if (imageReader == null) {
            Log.e(TAG, "imageReader is null");
            return null;
        }
        try {
            // Try up to 5 times to get a frame
            Image image = null;
            for (int i = 0; i < 5; i++) {
                image = imageReader.acquireLatestImage();
                if (image != null) break;
                Thread.sleep(100);
            }
            if (image == null) return null;

            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * screenW;

            Bitmap bmp = Bitmap.createBitmap(
                    screenW + rowPadding / pixelStride,
                    screenH, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buffer);
            image.close();

            if (bmp.getWidth() != screenW) {
                Bitmap cropped = Bitmap.createBitmap(bmp, 0, 0, screenW, screenH);
                bmp.recycle();
                return cropped;
            }
            return bmp;
        } catch (Exception e) {
            Log.e(TAG, "Capture error", e);
            return null;
        }
    }

    private void setStatus(String msg) {
        if (tvState != null) tvState.setText(msg);
    }

    @Override
    public void onDestroy() {
        buttonShown = false;
        ProjectionHolder.clear(); // prevent stale reference
        if (floatingView != null) { wm.removeView(floatingView); floatingView = null; }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (mediaProjection != null) { mediaProjection.stop(); mediaProjection = null; }
        if (imageReader != null) { imageReader.close(); imageReader = null; }
        if (engine != null) { engine.shutdown(); engine = null; }
        captureExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("MovieSorter")
                .setContentText("Running — tap the floating button")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "MovieSorter", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
}
