# MovieSorter

Auto-identifies movie posters on screen using ML Kit OCR, looks up release years via IMDB/OMDB, then taps them into the correct chronological slots.

## Build

1. Open in Android Studio (Hedgehog or newer)
2. Let Gradle sync
3. Build → Generate APK or run on device (API 26+)

## Setup on phone

1. Install APK
2. Open MovieSorter
3. Tap **"1. Grant Overlay Permission"** → enable for MovieSorter
4. Tap **"2. Grant Accessibility Permission"** → find MovieSorter in list → enable
5. Tap **"3. Start Service"** → allow screen capture when prompted
6. App closes → floating ▶ button appears on screen

## Usage

1. Open your game and navigate to the poster sorting screen
2. Tap the floating ▶ button
3. The app will:
   - Wait 0.8s (finger off screen)
   - Capture screenshot
   - Read all 4 poster titles via ML Kit OCR
   - Look up release years from IMDB/OMDB
   - Tap each poster into its correct year slot (oldest → newest)
4. Done in ~15-20 seconds total

## How it works

- **ML Kit OCR**: reads text directly off poster images — no internet needed for recognition
- **IMDB scraper**: searches imdb.com for release year
- **OMDB fallback**: if IMDB fails, tries omdbapi.com
- **Accessibility Service**: injects taps at exact screen coordinates
- **MediaProjection**: captures screen without root

## Notes

- If a poster has very little readable text, OCR may fail → that poster gets placed last
- The poster region detection is calibrated for the game layout in the screenshot
- If your screen resolution differs significantly, adjust the percentages in `PosterProcessor.detectPosterRegions()`
- Status text shows under the floating button so you can see what it's doing

## Poster region tuning

If taps land wrong, adjust these values in `PosterProcessor.java`:

```java
int startY = (int)(screenH * 0.50f);  // where posters start vertically
```

And in `FloatingService.java` slot positions:
```java
float slotY = screenH * 0.47f;  // vertical position of year slots
```
