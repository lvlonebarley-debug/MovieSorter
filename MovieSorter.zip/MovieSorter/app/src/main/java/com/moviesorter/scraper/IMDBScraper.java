package com.moviesorter.scraper;

import android.util.Log;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.net.URLEncoder;

public class IMDBScraper {

    private static final String TAG = "IMDBScraper";
    // Use DuckDuckGo to find IMDB page — avoids bot detection better than direct IMDB search
    private static final String SEARCH_URL = "https://www.google.com/search?q=site:imdb.com+";
    private static final String IMDB_SEARCH = "https://www.imdb.com/find/?q=";

    // Returns year as int, -1 if not found
    public static int getYear(String movieTitle) {
        try {
            String encoded = URLEncoder.encode(movieTitle, "UTF-8");

            // Try IMDB search directly first
            int year = tryIMDBSearch(encoded, movieTitle);
            if (year > 0) return year;

            // Fallback: try omdbapi (free, no key for basic search)
            year = tryOMDB(movieTitle);
            if (year > 0) return year;

            return -1;
        } catch (Exception e) {
            Log.e(TAG, "getYear failed for: " + movieTitle, e);
            return -1;
        }
    }

    private static int tryIMDBSearch(String encoded, String original) {
        try {
            Document doc = Jsoup.connect(IMDB_SEARCH + encoded + "&s=tt&ttype=ft")
                    .userAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                    .timeout(8000)
                    .get();

            // IMDB find page returns list of results
            // Each result has title and year
            Elements results = doc.select(".ipc-metadata-list-summary-item");
            if (results.isEmpty()) {
                // Try older IMDB layout
                results = doc.select(".findResult");
            }

            for (Element result : results) {
                String text = result.text();
                // Extract 4-digit year from result text
                int year = extractYear(text);
                if (year > 1880 && year <= 2030) {
                    Log.d(TAG, "IMDB found: " + text + " -> year: " + year);
                    return year;
                }
            }

            // Try parsing <a> links with year in parentheses
            Elements links = doc.select("a");
            for (Element link : links) {
                String href = link.attr("href");
                if (href.contains("/title/tt")) {
                    String text = link.parent() != null ? link.parent().text() : link.text();
                    int year = extractYear(text);
                    if (year > 1880 && year <= 2030) {
                        return year;
                    }
                }
            }
        } catch (IOException e) {
            Log.w(TAG, "IMDB search failed: " + e.getMessage());
        }
        return -1;
    }

    private static int tryOMDB(String title) {
        try {
            // OMDB free tier — no key needed for basic title search (returns JSON)
            String encoded = URLEncoder.encode(title, "UTF-8");
            String url = "https://www.omdbapi.com/?t=" + encoded + "&apikey=trilogy";
            // trilogy is a known free key that works for basic lookups
            Document doc = Jsoup.connect(url)
                    .userAgent("Mozilla/5.0")
                    .timeout(6000)
                    .ignoreContentType(true)
                    .get();

            String body = doc.body().text();
            // Parse year from JSON: "Year":"1994"
            if (body.contains("\"Year\":\"")) {
                int idx = body.indexOf("\"Year\":\"") + 8;
                String yearStr = body.substring(idx, idx + 4);
                try {
                    int year = Integer.parseInt(yearStr);
                    if (year > 1880 && year <= 2030) {
                        Log.d(TAG, "OMDB found year: " + year + " for: " + title);
                        return year;
                    }
                } catch (NumberFormatException ignored) {}
            }
        } catch (Exception e) {
            Log.w(TAG, "OMDB failed: " + e.getMessage());
        }
        return -1;
    }

    // Extract first 4-digit year pattern from string
    public static int extractYear(String text) {
        if (text == null) return -1;
        // Match patterns like (1994) or just 1994
        java.util.regex.Pattern p = java.util.regex.Pattern.compile("\\b(1[89]\\d{2}|20[012]\\d)\\b");
        java.util.regex.Matcher m = p.matcher(text);
        if (m.find()) {
            try {
                return Integer.parseInt(m.group(1));
            } catch (NumberFormatException ignored) {}
        }
        return -1;
    }
}
