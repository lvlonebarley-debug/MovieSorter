package com.moviesorter.scraper;

import android.util.Log;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.net.URLEncoder;

public class IMDBScraper {

    private static final String TAG = "IMDBScraper";

    public static int getYear(String movieTitle) {
        if (movieTitle == null || movieTitle.trim().isEmpty()) return -1;
        String clean = movieTitle.trim();

        // 1. Try Wikipedia API — free, no key, no bot blocking, returns JSON
        int year = tryWikipedia(clean);
        if (year > 0) return year;

        // 2. Try TheMovieDB (TMDB) search — free, no key needed for basic search via scrape
        year = tryTMDBScrape(clean);
        if (year > 0) return year;

        // 3. Try DuckDuckGo instant answer API
        year = tryDuckDuckGo(clean);
        if (year > 0) return year;

        return -1;
    }

    // Wikipedia API — most reliable, free, no scraping
    private static int tryWikipedia(String title) {
        try {
            String encoded = URLEncoder.encode(title + " film", "UTF-8");
            String url = "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch="
                    + encoded + "&format=json&srlimit=3";

            Document doc = Jsoup.connect(url)
                    .userAgent("MovieSorterApp/1.0")
                    .timeout(8000)
                    .ignoreContentType(true)
                    .get();

            String body = doc.body().text();

            // Look for year in snippet text
            int year = extractYear(body);
            if (year > 0) {
                Log.d(TAG, "Wikipedia found year " + year + " for: " + title);
                return year;
            }

            // Try fetching the actual page extract
            String encodedTitle = URLEncoder.encode(title, "UTF-8");
            String extractUrl = "https://en.wikipedia.org/w/api.php?action=query&titles="
                    + encodedTitle + "&prop=revisions&rvprop=content&rvsection=0&format=json";
            Document extractDoc = Jsoup.connect(extractUrl)
                    .userAgent("MovieSorterApp/1.0")
                    .timeout(8000)
                    .ignoreContentType(true)
                    .get();

            String extractBody = extractDoc.body().text();
            year = extractYear(extractBody);
            if (year > 0) {
                Log.d(TAG, "Wikipedia extract found year " + year + " for: " + title);
                return year;
            }
        } catch (Exception e) {
            Log.w(TAG, "Wikipedia failed: " + e.getMessage());
        }
        return -1;
    }

    // DuckDuckGo instant answer — returns JSON with film info
    private static int tryDuckDuckGo(String title) {
        try {
            String encoded = URLEncoder.encode(title + " film release year", "UTF-8");
            String url = "https://api.duckduckgo.com/?q=" + encoded + "&format=json&no_html=1&skip_disambig=1";

            Document doc = Jsoup.connect(url)
                    .userAgent("MovieSorterApp/1.0")
                    .timeout(8000)
                    .ignoreContentType(true)
                    .get();

            String body = doc.body().text();
            int year = extractYear(body);
            if (year > 0) {
                Log.d(TAG, "DuckDuckGo found year " + year + " for: " + title);
                return year;
            }
        } catch (Exception e) {
            Log.w(TAG, "DuckDuckGo failed: " + e.getMessage());
        }
        return -1;
    }

    // TMDB search via their public search page (no API key needed for HTML)
    private static int tryTMDBScrape(String title) {
        try {
            String encoded = URLEncoder.encode(title, "UTF-8");
            String url = "https://www.themoviedb.org/search?query=" + encoded;

            Document doc = Jsoup.connect(url)
                    .userAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                    .timeout(8000)
                    .get();

            // TMDB shows release year in search results
            Elements results = doc.select(".release_date");
            for (Element el : results) {
                int year = extractYear(el.text());
                if (year > 0) {
                    Log.d(TAG, "TMDB found year " + year + " for: " + title);
                    return year;
                }
            }

            // Fallback: scan all text for year pattern near movie title
            String text = doc.body().text();
            int year = extractYear(text);
            if (year > 0) return year;

        } catch (Exception e) {
            Log.w(TAG, "TMDB scrape failed: " + e.getMessage());
        }
        return -1;
    }

    // Year regex: 1880-2035
    public static int extractYear(String text) {
        if (text == null) return -1;
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "\\b(188\\d|189\\d|19\\d{2}|200\\d|201\\d|202\\d|203[0-5])\\b");
        java.util.regex.Matcher m = p.matcher(text);
        while (m.find()) {
            try {
                int year = Integer.parseInt(m.group(1));
                if (year >= 1888 && year <= 2035) return year;
            } catch (NumberFormatException ignored) {}
        }
        return -1;
    }
}
