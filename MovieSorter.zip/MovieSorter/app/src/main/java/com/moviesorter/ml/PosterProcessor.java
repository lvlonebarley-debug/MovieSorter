package com.moviesorter.ml;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class PosterProcessor {

    private static final String TAG = "PosterProcessor";
    private final TextRecognizer recognizer;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public PosterProcessor() {
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    public static class PosterRegion {
        public int index;
        public Rect bounds;
        public String title;
        public int year;
        public float centerX;
        public float centerY;

        public PosterRegion(int index, Rect bounds) {
            this.index = index;
            this.bounds = bounds;
            this.centerX = bounds.centerX();
            this.centerY = bounds.centerY();
        }
    }

    public static List<PosterRegion> detectPosterRegions(int screenW, int screenH) {
        List<PosterRegion> regions = new ArrayList<>();

        // From screenshot: posters start ~50% down, 2 cols 2 rows
        int startY = (int)(screenH * 0.50f);
        int posterW = screenW / 2;
        int posterH = (int)(screenH * 0.25f);

        int[][] grid = { {0,0}, {1,0}, {0,1}, {1,1} };

        for (int i = 0; i < 4; i++) {
            int col = grid[i][0];
            int row = grid[i][1];
            int left  = col * posterW + 10;
            int top   = startY + row * posterH + 10;
            int right  = left + posterW - 20;
            int bottom = top  + posterH - 20;
            regions.add(new PosterRegion(i, new Rect(left, top, right, bottom)));
        }
        return regions;
    }

    public static float[] detectSlotPositions(int screenW, int screenH) {
        // Slots are the 4 dashed boxes — roughly at 40% screen height center
        float slotY = screenH * 0.42f;
        float slotW = screenW / 4f;
        float[] positions = new float[8];
        for (int i = 0; i < 4; i++) {
            positions[i * 2]     = slotW * i + slotW / 2f;
            positions[i * 2 + 1] = slotY;
        }
        return positions;
    }

    public String extractTitle(Bitmap fullScreen, PosterRegion region) {
        Rect b = region.bounds;
        int x = Math.max(0, b.left);
        int y = Math.max(0, b.top);
        int w = Math.min(b.width(),  fullScreen.getWidth()  - x);
        int h = Math.min(b.height(), fullScreen.getHeight() - y);
        if (w <= 0 || h <= 0) return "";

        // Keep reference — don't recycle until ML Kit fully done
        final Bitmap crop = Bitmap.createBitmap(fullScreen, x, y, w, h);
        InputImage image = InputImage.fromBitmap(crop, 0);

        final AtomicReference<String> result = new AtomicReference<>("");
        final CountDownLatch latch = new CountDownLatch(1);

        mainHandler.post(() ->
            recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    result.set(pickBestTitle(visionText));
                    crop.recycle(); // safe — ML Kit done
                    latch.countDown();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "ML Kit failed", e);
                    crop.recycle();
                    latch.countDown();
                })
        );

        try {
            latch.await(6000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {}

        return result.get();
    }

    private String pickBestTitle(Text visionText) {
        if (visionText.getTextBlocks().isEmpty()) return "";

        Text.TextBlock best = null;
        float bestScore = 0;

        for (Text.TextBlock block : visionText.getTextBlocks()) {
            String text = block.getText().trim();
            if (text.isEmpty() || text.length() < 2) continue;

            String upper = text.toUpperCase();

            // Skip obvious non-title text — but NOT year-containing titles
            if (upper.contains("RATED") || upper.contains("COPYRIGHT") ||
                upper.contains("ALL RIGHTS RESERVED") ||
                upper.startsWith("WWW.") || upper.startsWith("HTTP") ||
                upper.contains("PRESENTS") || upper.contains("PRODUCTION")) {
                continue;
            }

            Rect bounds = block.getBoundingBox();
            float area = bounds != null ? bounds.width() * (float)bounds.height() : 0;

            // Bonus for all-caps (common on movie posters)
            boolean isAllCaps = text.equals(text.toUpperCase()) && text.matches(".*[A-Z].*");
            float capsBonus = isAllCaps ? 1.5f : 1.0f;

            // Bonus for longer text (titles usually > 3 chars)
            float lengthBonus = text.length() > 3 ? 1.2f : 1.0f;

            float score = area * capsBonus * lengthBonus;
            if (score > bestScore) {
                bestScore = score;
                best = block;
            }
        }

        if (best == null) {
            return visionText.getText().replace("\n", " ").trim();
        }

        return best.getText().replaceAll("[\\r\\n]+", " ").trim();
    }

    public void shutdown() {
        recognizer.close();
    }
}
