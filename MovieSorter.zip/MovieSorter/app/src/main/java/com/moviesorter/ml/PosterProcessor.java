package com.moviesorter.ml;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.util.Log;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;

public class PosterProcessor {

    private static final String TAG = "PosterProcessor";
    private final TextRecognizer recognizer;

    public PosterProcessor() {
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    public static class PosterRegion {
        public int index;       // 0-3
        public Rect bounds;     // pixel bounds on screen
        public String title;    // extracted movie title
        public int year;        // looked up year
        public float centerX;
        public float centerY;

        public PosterRegion(int index, Rect bounds) {
            this.index = index;
            this.bounds = bounds;
            this.centerX = bounds.centerX();
            this.centerY = bounds.centerY();
        }
    }

    // Detect poster regions from screenshot
    // Based on the game layout: 2x2 grid in bottom half of screen
    public static List<PosterRegion> detectPosterRegions(int screenW, int screenH) {
        List<PosterRegion> regions = new ArrayList<>();

        // From screenshot analysis:
        // Screen is ~720x1560 (approx)
        // Posters start at ~60% of screen height
        // 2 columns, 2 rows visible
        // Each poster ~half width, ~quarter height

        int startY = (int)(screenH * 0.50f);  // posters start at 50% down
        int posterW = screenW / 2;
        int posterH = (int)(screenH * 0.25f);

        // 4 posters: top-left, top-right, bottom-left, bottom-right
        int[][] grid = {
            {0, 0},  // top-left
            {1, 0},  // top-right
            {0, 1},  // bottom-left
            {1, 1},  // bottom-right
        };

        for (int i = 0; i < 4; i++) {
            int col = grid[i][0];
            int row = grid[i][1];
            int left = col * posterW + 10;
            int top = startY + row * posterH + 10;
            int right = left + posterW - 20;
            int bottom = top + posterH - 20;
            regions.add(new PosterRegion(i, new Rect(left, top, right, bottom)));
        }

        return regions;
    }

    // Detect slot regions (the year target slots at top of screen)
    // Returns array of 4 slot center X positions, Y is fixed
    public static float[] detectSlotPositions(int screenW, int screenH) {
        // From screenshot: 4 slots at ~35% down screen, evenly spaced
        float slotY = screenH * 0.47f;  // just above "Tap to Place" text
        float slotW = screenW / 4f;
        float[] positions = new float[8]; // [x0,y0, x1,y1, x2,y2, x3,y3]
        for (int i = 0; i < 4; i++) {
            positions[i * 2] = slotW * i + slotW / 2f;
            positions[i * 2 + 1] = slotY;
        }
        return positions;
    }

    // Extract movie title text from poster bitmap crop
    // Returns best candidate title string
    public String extractTitle(Bitmap fullScreen, PosterRegion region) {
        Rect b = region.bounds;
        // Clamp to bitmap bounds
        int x = Math.max(0, b.left);
        int y = Math.max(0, b.top);
        int w = Math.min(b.width(), fullScreen.getWidth() - x);
        int h = Math.min(b.height(), fullScreen.getHeight() - y);
        if (w <= 0 || h <= 0) return "";

        Bitmap crop = Bitmap.createBitmap(fullScreen, x, y, w, h);
        InputImage image = InputImage.fromBitmap(crop, 0);

        final AtomicReference<String> result = new AtomicReference<>("");
        final CountDownLatch latch = new CountDownLatch(1);

        recognizer.process(image)
                .addOnSuccessListener(visionText -> {
                    result.set(pickBestTitle(visionText));
                    latch.countDown();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "ML Kit failed", e);
                    latch.countDown();
                });

        try {
            latch.await(5000, java.util.concurrent.TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {}

        crop.recycle();
        return result.get();
    }

    // Pick the most likely movie title from recognized text blocks
    // Movie titles are typically the largest/most prominent text on a poster
    private String pickBestTitle(Text visionText) {
        if (visionText.getTextBlocks().isEmpty()) return "";

        Text.TextBlock best = null;
        float bestScore = 0;

        for (Text.TextBlock block : visionText.getTextBlocks()) {
            String text = block.getText().trim();
            if (text.isEmpty() || text.length() < 2) continue;

            // Skip common non-title text
            String upper = text.toUpperCase();
            if (upper.contains("RATED") || upper.contains("COPYRIGHT") ||
                upper.contains("ALL RIGHTS") || upper.contains("www.") ||
                upper.contains("HTTP") || text.matches(".*\\d{4}.*")) {
                continue;
            }

            // Score: larger bounding box = more prominent = likely title
            Rect bounds = block.getBoundingBox();
            float area = bounds != null ? bounds.width() * bounds.height() : 0;

            // Bonus for all-caps (movie titles often all caps on posters)
            float capsBonus = text.equals(text.toUpperCase()) ? 1.5f : 1.0f;

            float score = area * capsBonus;
            if (score > bestScore) {
                bestScore = score;
                best = block;
            }
        }

        if (best == null) {
            // Fallback: just return all text joined
            return visionText.getText().replace("\n", " ").trim();
        }

        return best.getText().replace("\n", " ").trim();
    }

    public void shutdown() {
        recognizer.close();
    }
}
