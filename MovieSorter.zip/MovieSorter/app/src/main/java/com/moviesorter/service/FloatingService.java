package com.moviesorter.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import com.moviesorter.R;
import com.moviesorter.ml.PosterProcessor;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FloatingService extends Service {

    private static final String TAG = "FloatingService";
    private static final String CHANNEL_ID = "MovieSorterChannel";
    private static final int NOTIF_ID = 1;

    private WindowManager wm;
    private View floatingView;
    private TextView tvState;
    private boolean buttonShown = false;

    private MediaProjection mediaProjection;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;

    private int screenW, screenH, screenDpi;
    private SortEngine engine;
    private boolean isBusy = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService captureExecutor = Executors.newSingleThreadExecutor();

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        engine = new SortEngine();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        screenDpi = dm.densityDpi;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            int resultCode = intent.getIntExtra("resultCode", -1);
            Intent data = intent.getParcelableExtra("data");
            if (resultCode != -1 && data != null) {
                MediaProjectionManager mpm =
                        (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                mediaProjection = mpm.getMediaProjection(resultCode, data);

                // Required on Android 14+ or projection dies silently
                mediaProjection.registerCallback(new MediaProjection.Callback() {
                    @Override
                    public void onStop() {
                        Log.w(TAG, "MediaProjection stopped");
                        mediaProjection = null;
                    }
                }, mainHandler);

                setupImageReader();
            }
        }
        // Only add floating button once
        if (!buttonShown) {
            showFloatingButton();
            buttonShown = true;
        }
        return START_STICKY;
    }

    private void setupImageReader() {
        imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "MovieSorterCapture",
                screenW, screenH, screenDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, null);
    }

    private void showFloatingButton() {
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_button, null);
        tvState = floatingView.findViewById(R.id.tvState);

        // Play button — separate listener, not part of drag
        floatingView.findViewById(R.id.btnFloat).setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_UP) onButtonClick();
            return true;
        });

        // Close button
        floatingView.findViewById(R.id.btnClose).setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_UP) stopSelf();
            return true;
        });

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 16;
        params.y = 200;

        floatingView.setOnTouchListener(new View.OnTouchListener() {
            int initX, initY;
            float initTouchX, initTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initX = params.x; initY = params.y;
                        initTouchX = e.getRawX(); initTouchY = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(e.getRawX() - initTouchX);
                        int dy = (int)(e.getRawY() - initTouchY);
                        params.x = initX + dx;
                        params.y = initY + dy;
                        wm.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });

        wm.addView(floatingView, params);
    }

    private void onButtonClick() {
        if (isBusy) {
            isBusy = false;
            setStatus("▶ Ready");
            return;
        }

        if (mediaProjection == null) {
            Toast.makeText(this, "No screen capture — restart app", Toast.LENGTH_SHORT).show();
            return;
        }

        TapAccessibilityService acc = TapAccessibilityService.getInstance();
        if (acc == null) {
            setStatus("⚠ Enable MovieSorter Tap in Accessibility first");
            return;
        }

        isBusy = true;
        setStatus("📸 Capturing...");

        // Delay so finger is off screen, then capture on background thread
        mainHandler.postDelayed(() -> captureExecutor.execute(this::captureAndProcess), 800);
    }

    private void captureAndProcess() {
        Bitmap screenshot = captureScreen();
        if (screenshot == null) {
            mainHandler.post(() -> { setStatus("❌ Capture failed"); isBusy = false; });
            return;
        }

        mainHandler.post(() -> setStatus("🔍 Reading posters..."));

        engine.process(screenshot, screenW, screenH, new SortEngine.Callback() {
            @Override
            public void onLog(String msg) {
                Log.d(TAG, msg);
                mainHandler.post(() -> setStatus(msg));
            }

            @Override
            public void onDone(List<PosterProcessor.PosterRegion> sorted, float[] slotPositions) {
                screenshot.recycle();
                mainHandler.post(() -> executeTaps(sorted, slotPositions));
            }

            @Override
            public void onError(String msg) {
                screenshot.recycle();
                mainHandler.post(() -> { setStatus("❌ " + msg); isBusy = false; });
            }
        });
    }

    private void executeTaps(List<PosterProcessor.PosterRegion> sorted, float[] slots) {
        TapAccessibilityService acc = TapAccessibilityService.getInstance();
        if (acc == null) {
            setStatus("❌ Accessibility lost");
            isBusy = false;
            return;
        }
        setStatus("👆 Tapping...");
        tapNext(acc, sorted, slots, 0);
    }

    private void tapNext(TapAccessibilityService acc,
                         List<PosterProcessor.PosterRegion> sorted,
                         float[] slots, int index) {
        if (index >= sorted.size()) {
            mainHandler.post(() -> { setStatus("✅ Done!"); isBusy = false; });
            return;
        }

        PosterProcessor.PosterRegion poster = sorted.get(index);
        float slotX = slots[index * 2];
        float slotY = slots[index * 2 + 1];

        String title = poster.title != null ? poster.title : "?";
        if (title.length() > 20) title = title.substring(0, 20) + "...";
        final String displayTitle = title;

        mainHandler.post(() -> setStatus("👆 Placing: " + displayTitle));

        // Use handler delays instead of Thread.sleep
        acc.tapPosterThenSlot(poster.centerX, poster.centerY, slotX, slotY, () ->
            mainHandler.postDelayed(() -> tapNext(acc, sorted, slots, index + 1), 800)
        );
    }

    private Bitmap captureScreen() {
        try {
            // Try up to 5 times to get a frame
            Image image = null;
            for (int i = 0; i < 5; i++) {
                image = imageReader.acquireLatestImage();
                if (image != null) break;
                Thread.sleep(100);
            }
            if (image == null) return null;

            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * screenW;

            Bitmap bmp = Bitmap.createBitmap(
                    screenW + rowPadding / pixelStride,
                    screenH, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buffer);
            image.close();

            if (bmp.getWidth() != screenW) {
                Bitmap cropped = Bitmap.createBitmap(bmp, 0, 0, screenW, screenH);
                bmp.recycle();
                return cropped;
            }
            return bmp;
        } catch (Exception e) {
            Log.e(TAG, "Capture error", e);
            return null;
        }
    }

    private void setStatus(String msg) {
        if (tvState != null) tvState.setText(msg);
    }

    @Override
    public void onDestroy() {
        buttonShown = false;
        if (floatingView != null) { wm.removeView(floatingView); floatingView = null; }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (mediaProjection != null) { mediaProjection.stop(); mediaProjection = null; }
        if (imageReader != null) { imageReader.close(); imageReader = null; }
        if (engine != null) { engine.shutdown(); engine = null; }
        captureExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("MovieSorter")
                .setContentText("Running — tap the floating button")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "MovieSorter", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
}
