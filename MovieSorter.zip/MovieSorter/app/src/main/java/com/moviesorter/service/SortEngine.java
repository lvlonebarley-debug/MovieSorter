package com.moviesorter.service;

import android.graphics.Bitmap;
import android.util.Log;
import com.moviesorter.ml.PosterProcessor;
import com.moviesorter.scraper.IMDBScraper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SortEngine {

    private static final String TAG = "SortEngine";
    private final PosterProcessor processor;
    private final ExecutorService pool;

    public interface Callback {
        void onLog(String msg);
        void onDone(List<PosterProcessor.PosterRegion> sortedPosters, float[] slotPositions);
        void onError(String msg);
    }

    public SortEngine() {
        processor = new PosterProcessor();
        pool = Executors.newFixedThreadPool(4); // parallel processing
    }

    public void process(Bitmap screenshot, int screenW, int screenH, Callback cb) {
        pool.execute(() -> {
            try {
                cb.onLog("Detecting poster regions...");
                List<PosterProcessor.PosterRegion> regions =
                        PosterProcessor.detectPosterRegions(screenW, screenH);

                float[] slotPositions = PosterProcessor.detectSlotPositions(screenW, screenH);

                cb.onLog("Reading " + regions.size() + " posters in parallel...");

                // Run ML Kit on all 4 posters in parallel
                List<Future<String>> titleFutures = new ArrayList<>();
                for (PosterProcessor.PosterRegion region : regions) {
                    final PosterProcessor.PosterRegion r = region;
                    titleFutures.add(pool.submit(() -> processor.extractTitle(screenshot, r)));
                }

                // Collect titles
                List<String> titles = new ArrayList<>();
                for (int i = 0; i < regions.size(); i++) {
                    try {
                        String title = titleFutures.get(i).get();
                        regions.get(i).title = title;
                        titles.add(title);
                        cb.onLog("Poster " + (i+1) + ": \"" + title + "\"");
                    } catch (Exception e) {
                        regions.get(i).title = "";
                        cb.onLog("Poster " + (i+1) + ": failed to read");
                    }
                }

                cb.onLog("Looking up release years...");

                // Look up years in parallel
                List<Future<Integer>> yearFutures = new ArrayList<>();
                for (PosterProcessor.PosterRegion region : regions) {
                    final String title = region.title;
                    yearFutures.add(pool.submit(() -> {
                        if (title == null || title.isEmpty()) return -1;
                        return IMDBScraper.getYear(title);
                    }));
                }

                // Collect years
                for (int i = 0; i < regions.size(); i++) {
                    try {
                        int year = yearFutures.get(i).get();
                        regions.get(i).year = year;
                        cb.onLog("\"" + regions.get(i).title + "\" -> " + year);
                    } catch (Exception e) {
                        regions.get(i).year = -1;
                    }
                }

                // Sort by year ascending (oldest first)
                List<PosterProcessor.PosterRegion> sorted = new ArrayList<>(regions);
                Collections.sort(sorted, (a, b) -> {
                    if (a.year < 0) return 1;
                    if (b.year < 0) return -1;
                    return Integer.compare(a.year, b.year);
                });

                cb.onLog("Sort order:");
                for (int i = 0; i < sorted.size(); i++) {
                    cb.onLog("  Slot " + (i+1) + ": " + sorted.get(i).title + " (" + sorted.get(i).year + ")");
                }

                cb.onDone(sorted, slotPositions);

            } catch (Exception e) {
                Log.e(TAG, "Engine error", e);
                cb.onError(e.getMessage());
            }
        });
    }

    public void shutdown() {
        processor.shutdown();
        pool.shutdownNow();
    }
}
