package com.moviesorter.service;

import android.graphics.Bitmap;
import android.util.Log;
import com.moviesorter.ml.PosterProcessor;
import com.moviesorter.scraper.IMDBScraper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class SortEngine {

    private static final String TAG = "SortEngine";
    private final PosterProcessor processor;
    private final ExecutorService pool;

    public interface Callback {
        void onLog(String msg);
        void onDone(List<PosterProcessor.PosterRegion> sortedPosters, float[] slotPositions);
        void onError(String msg);
    }

    public SortEngine() {
        processor = new PosterProcessor();
        pool = Executors.newFixedThreadPool(4);
    }

    public void process(Bitmap screenshot, int screenW, int screenH, Callback cb) {
        pool.execute(() -> {
            try {
                cb.onLog("Detecting poster regions...");
                List<PosterProcessor.PosterRegion> regions =
                        PosterProcessor.detectPosterRegions(screenW, screenH);
                float[] slotPositions = PosterProcessor.detectSlotPositions(screenW, screenH);

                cb.onLog("Reading " + regions.size() + " posters...");

                // ML Kit must run sequentially via main thread handler — parallel calls
                // to the same recognizer can deadlock. Run them one by one.
                for (int i = 0; i < regions.size(); i++) {
                    PosterProcessor.PosterRegion region = regions.get(i);
                    try {
                        String title = processor.extractTitle(screenshot, region);
                        region.title = title != null ? title : "";
                        cb.onLog("Poster " + (i+1) + ": \"" + region.title + "\"");
                    } catch (Exception e) {
                        region.title = "";
                        cb.onLog("Poster " + (i+1) + ": read failed");
                    }
                }

                cb.onLog("Looking up release years...");

                // Year lookups can be parallel (network calls)
                List<Future<Integer>> yearFutures = new ArrayList<>();
                for (PosterProcessor.PosterRegion region : regions) {
                    final String title = region.title;
                    yearFutures.add(pool.submit(() -> {
                        if (title == null || title.isEmpty()) return -1;
                        return IMDBScraper.getYear(title);
                    }));
                }

                for (int i = 0; i < regions.size(); i++) {
                    try {
                        int year = yearFutures.get(i).get(15, TimeUnit.SECONDS);
                        regions.get(i).year = year;
                        cb.onLog("\"" + regions.get(i).title + "\" -> " + year);
                    } catch (Exception e) {
                        regions.get(i).year = -1;
                        cb.onLog("Year lookup failed for poster " + (i+1));
                    }
                }

                // Sort oldest to newest
                List<PosterProcessor.PosterRegion> sorted = new ArrayList<>(regions);
                Collections.sort(sorted, (a, b) -> {
                    if (a.year < 0 && b.year < 0) return 0;
                    if (a.year < 0) return 1;
                    if (b.year < 0) return -1;
                    return Integer.compare(a.year, b.year);
                });

                for (int i = 0; i < sorted.size(); i++) {
                    cb.onLog("Slot " + (i+1) + ": " + sorted.get(i).title + " (" + sorted.get(i).year + ")");
                }

                cb.onDone(sorted, slotPositions);

            } catch (Exception e) {
                Log.e(TAG, "Engine error", e);
                cb.onError(e.getMessage() != null ? e.getMessage() : "Unknown error");
            }
        });
    }

    public void shutdown() {
        processor.shutdown();
        pool.shutdownNow();
    }
}
