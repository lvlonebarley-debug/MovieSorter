package com.moviesorter.service;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class TapAccessibilityService extends AccessibilityService {

    private static TapAccessibilityService instance;

    public static TapAccessibilityService getInstance() {
        return instance;
    }

    @Override
    public void onServiceConnected() {
        instance = this;
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    // Tap at x,y then call callback when done
    public void tap(float x, float y, Runnable onDone) {
        Path path = new Path();
        path.moveTo(x, y);

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 100);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(stroke)
                .build();

        dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                if (onDone != null) onDone.run();
            }
            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                if (onDone != null) onDone.run();
            }
        }, null);
    }

    // Tap poster then tap target slot with delay between
    public void tapPosterThenSlot(float posterX, float posterY,
                                   float slotX, float slotY,
                                   Runnable onDone) {
        tap(posterX, posterY, () -> {
            try { Thread.sleep(600); } catch (InterruptedException ignored) {}
            tap(slotX, slotY, onDone);
        });
    }
}
